# salapi-tracker
Salapi (SLP) Tracker for Axie Managers and Scholars
